
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int nRows = 5;
int nCols = 5;


double f(double x)
{
	const double pi = 3.14159265359;
	return sin(pi * x);
}

double g(double x)
{
	return 0;
}

int main()
{
	//Step one 
	double l = 1.0, T = 1.0;
	const int alpha = 2.0;
	double h = l/nRows;
	double k = T/nCols;
	double lambda;
	lambda = k*alpha / h;
	int i,j;

	double *w = (double *)malloc((nRows+1) * (nCols+1) * sizeof(double)); 
	
	
	//step three
	*(w + 0*nCols +0) = 0;
	*(w + 0+ (nRows*nCols-1)) = f(l);
	
	//Step two
	
	for (j = 1; j < nCols; j++ )
	{
		*(w+j + nCols*0) = 0;	
		*(w+j + (nCols*nRows-1)) = 0;	
	}
	
	
	
	//Step four
	for (i = 1; i < nRows; i++ )
	{
		*(w+0 + nCols*i) = f(i*h);	
		*(w+1 + nCols*i) = (1 - pow(lambda,2))*f(i*h)+
		 (pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h);	
	}
	
	//Step five
	
	for (i = 1; i < nRows; i++)
	{
		for (j = 1; j < nCols; j++)
		{ 
         *(w+(j+1) + nCols*i) = 2*(1-pow(lambda,2))* (*(w +j+ nCols*i)) + 
         pow(lambda,2)*(*(w +j+ nCols*(i+1)) + (*(w +j+ nCols*(i-1))))- (*(w +(j-1)+ nCols*i));
	
		}
	}
	
	//~ //Step Six
	double t,x;
	printf("t\tx \t\t\t wij\n");
	for ( i = 0; i <= nRows; i++)
	{
		//for ( j = 0; j <= nCols; j++){
			x = i*h;
			printf("%d\t%f\t\t%f\n",(20+ nCols*i),x,*(w+20+ nCols*i));
		//}	
	}	
	
	
	free(w);
	
		
	return 0;
}
