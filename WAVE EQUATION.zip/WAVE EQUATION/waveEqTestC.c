#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int nRows = 4;
int nCols = 4;
//~ w[i][j]
//~ w[0][0]---0
//~ w[0][1]---1
//~ w[0][2]---2
//~ w[0][3]---3

//~ w[1][0] ---4
//~ w[1][1]---5
//~ w[1][2]---6
//~ w[1][3]---7

//~ w[2][0]---8
//~ w[2][1]---9
//~ w[2][2]---10
//~ w[2][3]---11

//~ w[3][0]---12
//~ w[3][1]---13
//~ w[3][2]---14
//~ w[3][3]---15




int main()
{
	//Step one 
	double l = 1.0, T = 1.0;
	const int alpha = 2.0;
	double h = l/nRows;
	double k = T/nCols;
	double lambda;
	lambda = k*alpha / h;
	int i,j;

	double *A = (double *)malloc((nRows+1) * (nCols+1) * sizeof(double)); 
	*(A + 0*nCols +0) = 7;
	*(A + (nRows*nCols)-1) = 7;
	
	for (i = 0; i < nRows; i++)
	{
		for (j = 0; j < nCols; j++)
		{
	
			//*(A + j*nRows +i) = i;
			//*(A + nRows*nRows +j) = 0;
			//printf(" index %d\n", ((i-1)*nCols +j));
			//printf(" index %d\n", (j + nCols*(i)));
			printf(" Aij = %f\n", *(A+j + nCols*(i)));
		}
	}
	free(A);
	
		
	return 0;
}
