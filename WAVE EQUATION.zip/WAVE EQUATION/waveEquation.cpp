#include <iostream>
#include <math.h>

#define N 20
#define m 10

double f(double x)
{
	const double pi = 3.14;
	return sin(pi * x);
}

double g(double x)
{
	return 0;
}

int main()

{
	//Step one 
	double l = 1.0, T = 1.0;
	//int m = 10,N = 20;
	const int alpha = 2;
	double h = l/m;
	double k = T/N;
	double lambda;
	lambda = k*alpha / h;
	
	//Step two
	double w[m][N];

	for (int j = 0; j < N; j++)
	{
		w[0][j] = 0;
		w[m][j] = 0;
	}
	//Step three
	
	w[0][0] = f(0);
	w[m][0] = f(l);
	
	//Step four
	for (int i = 0; i < m; i++)
	{
		w[i][0] = f(i*h);
		w[i][0] = (1 - pow(lambda,2))*f(i*h)+(pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h); 
	}
	//Step five
	for (int j = 0; j < N; j++)
	{
		for (int i = 0; i < m; i++)
		{
			w[i][j+1] = 2*(1-pow(lambda,2))*w[i][j] + pow(lambda,2)*(w[i+1][j] + w[i-1][j])-w[i][j-1];
		}	
	}
	//Step six
	double t,x;
	std::cout<<"x"<<"    \t  "<<"wij"<<std::endl;
	for (int j = 0; j < N; j++)
	{
		t = j*k;
		for (int i = 0; i < m; i++)
		{
			x = i*h;
			std::cout <<x <<"  "<<w[i][j] <<std::endl;	
		}
	}
	return 0;
}
