rm *.o *.exe *.txt

echo "Running in serial" # (WON'T READ THE OMP CLAUSES/DIRECTIVES)

g++ -c waveEquationOpenMp1D.cpp
g++ -o waveEquationOpenMp1D.exe waveEquationOpenMp1D.o -lm
time ./waveEquationOpenMp1D.exe >> serialOutput.txt

# rm *.o *.exe

echo "Running in parallel" # (WILL READ THE OMP CLAUSES/DIRECTIVES)
g++ -DOMP -fopenmp -c waveEquationOpenMp1D.cpp
g++ -DOMP -fopenmp -o waveEquationOpenMp1D.exe waveEquationOpenMp1D.o -lm
time ./waveEquationOpenMp1D.exe >> parallelOutput.txt
