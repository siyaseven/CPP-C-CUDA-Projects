// 1. OpenMP skeleton, just identifies the workers in the parallel
// environment. 
// 2. Include OMP parallel for directives to parallelise the wave 
// application.


#include <cstdlib> // includes all the standard c libraries to cpp
#include <iostream> // input- output operations cpp
#include <iomanip> // input-output manipulations  (eg.. precision)
#include <math.h>

#ifdef OMP
	#include <omp.h> // include openmp operations (variables, functions, etc.)
#else
	int omp_get_num_threads() {return 1;} // 
	int omp_get_thread_num() {return 0;}
#endif
 


#define N 20
#define m 10

double f(double x)
{
	const double pi = 3.14159265359;
	return sin(pi * x);
}

double g(double x)
{
	return 0;
}

int main()
{
	//Step one 
	double l = 1.0, T = 1.0;
	//int m = 10,N = 20;
	const double alpha = 2.0;
	double h = l/m;
	double k = T/N;
	double lambda;
	lambda = k*alpha / h;
	
	//Step two (use dynamic memory allocation, malloc or new)
	//double w[m][N];
	
	//double *w;
	//w = malloc(m * N * sizeof(double));
	//# pragma omp parallel
	{
		//The next loop is parallelised already.
		//#pragma omp for
		for (int j = 1; j <= N; j++)
		{
			w[0][j] = 0;
			w[m][j] = 0;
		}
	}
	
	//Step three
	
	w[0][0] = f(0);
	w[m][0] = f(l);
	
	//Step four
	//# pragma omp parallel for num_threads(4) //  the next loop is parallelised already.
	for (int i = 1; i < m; i++)
	{
		w[i][0] = f(i*h);
		w[i][1] = (1 - pow(lambda,2))*f(i*h)+(pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h); 
	}
	//Step five
	//# pragma omp parallel for //  the next loop is parallelised already.
	for (int j = 1; j < N; j++)
	{
		//# pragma omp parallel for num_threads(4)  //  the next loop is parallelised already.
		for (int i = 1; i < m; i++)
		{
			w[i][j+1] = 2*(1-pow(lambda,2))*w[i][j] + pow(lambda,2)*(w[i+1][j] + w[i-1][j])-w[i][j-1];
		}	
	}
	//Step six
	double t,x;
	//std::cout<<"x"<<"    \t  "<<"wij"<<std::endl;
	
	// Generate Mesh Points: Values of t and x
	//# pragma omp parallel for //  the next loop is parallelised already.
	for (int j = 0; j <= N; j++)
	{
		t = j*k;
		//# pragma omp parallel for // uncomment if desired
		for (int i = 0; i <= m; i++)
		{
			x = i*h;	
		}
	}
	
	// Don't parallelise the output for now 
	// OUTPUT when j = 20 (Use FSTREAM to write to a file)
	for (int i = 0; i <= m; i++)
	{
		x = i*h;
		std::cout.precision (10);
		std::cout <<x <<"\t  "<<w[i][20] <<std::endl;	
	}
	
	return 0;
}

 
 
 
 
 
 
 
 
 
 
 
 
 
// CHECK OMP ACTIVATIONS BELOW
//~ int main()
//~ {
	//~ // In the parallel environment: we've have workers
	//~ int numberOfThreads;
	//~ int threadIdx;
	
	//~ // Let's check the number of threads
	//~ #pragma omp parallel // preprocessor directive *(pragma)
	//~ {//begin activate
		//~ numberOfThreads = omp_get_num_threads();
		//~ threadIdx = omp_get_thread_num(); 
		 
		//std::cout<< "I'm thread = " << threadIdx << " working in the parallel environment, having a group of "
		//		<< numberOfThreads << " threads " << std::endl; 
		//~ printf("I'm thread = %d working in the parallel environment, having a group of %d threads \n",threadIdx, numberOfThreads);
		
	//~ }//deactivate
//~ }
