#include <mpi.h>
#include <stdio.h>
void main(int argc, char **argv)
{
	int nprocs, myrank, tag, rc;
	float sendbuf, recvbuf;
	MPI_Request req;
	MPI_Status status;

	//rc = MPI_Init(&argc, &argv);
	MPI_Init(&argc, &argv);
	//rc = MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	//rc = MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	//~ tag = 1;
	//~ if (myrank == 0)
	//~ {
		//~ sendbuf = 9.0;
		//~ rc = MPI_Send(&sendbuf, 1, MPI_FLOAT,1, tag, MPI_COMM_WORLD);
	//~ } 
	//~ else if (myrank == 1) 
	//~ {
		//~ rc = MPI_Irecv(&recvbuf, 1, MPI_FLOAT,0, tag, MPI_COMM_WORLD, &req);
		//~ rc = MPI_Wait(&req, &status);
		//~ printf("recvbuf = %f\n", recvbuf);
	//~ }
	printf("I am rank %d working in the MPI parallel environment \n",myrank);
	//rc = MPI_Finalize();
	MPI_Finalize();
}
