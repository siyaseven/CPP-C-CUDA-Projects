#include <iostream>
#include <vector>
#include <algorithm>

#define n 11

int main ()
{
	int a[n], b[n], i,j;
	
	for (i = 1; i <= n; i++)
	{
		b[i] = i;
	}
	
	for (i = 2; i < n; i++)
	{
		a[i] = b[i-1] + b[i+1];
		std::cout<<a[i]<<std::endl;
	}
	
	return 0;
}
