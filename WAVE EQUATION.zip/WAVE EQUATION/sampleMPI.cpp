#include <mpi.h>
#include <stdio.h>
int main(int argc, char **argv)
{
	int nprocs, myrank,ista,iend;
	MPI_Request req;
	MPI_Status status;
	//Activate MPI
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	CALL_para_range(1,n,nprocs,myrank,ista,iend);
	
	
	printf("I am rank %d working in the MPI parallel environment %d \n",myrank, nprocs);
	
	//Deactivate MPI
	MPI_Finalize();
	return 0;
}
