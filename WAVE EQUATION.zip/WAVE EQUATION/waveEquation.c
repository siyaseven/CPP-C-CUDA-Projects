#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//#define N 20
//#define m 10
int m = 10;
int N = 20;
double f(double x)
{
	const double pi = 3.14159265359;
	return sin(pi * x);
}

double g(double x)
{
	return 0;
}
int main()
{
	//Step one 
	double l = 1.0, T = 1.0;
	const int alpha = 2.0;
	double h = l/m;
	double k = T/N;
	double lambda;
	lambda = k*alpha / h;
	
	//Step two
	//double w[m+1][N+1];
	double *w;
	w = (double *) malloc((m+1) * (N+1) * sizeof(double));
	
	for (int j = 1; j <= N; j++)
	{
		w[0][j] = 0;
		w[m][j] = 0;
	}
	
	//Step three
	
	w[0][0] = f(0);
	w[m][0] = f(l);
	
	//~ //Step four
	//~ for (int i = 1; i < m; i++)
	//~ {
		//~ w[i][0] = f(i*h);
		//~ w[i][1] = (1 - pow(lambda,2))*f(i*h)+
		//~ (pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h); 
	//~ }
	//~ //Step five
	//~ for (int j = 1; j < N; j++)
	//~ {
		//~ for (int i = 1; i < m; i++)
		//~ {
			//~ w[i][j+1] = 2*(1-pow(lambda,2))*w[i][j] + 
			//~ pow(lambda,2)*(w[i+1][j] + w[i-1][j])-w[i][j-1];
		//~ }
		
	//~ }
	//~ //Step six
	//~ printf("x \t\t\t wij\n");
	//~ double t,x;
	//~ for (int j = 0; j < N; j++)
	//~ {
		//~ t = j*k;
		//~ for (int i = 0; i < m; i++)
		//~ {
			//~ x = i*h;		
		//~ }	
	//~ }
	//~ for (int i = 0; i <= m; i++)
		//~ {	
			//~ x = i*h;
			//~ printf("%f\t\t%f\n",x,w[i][20]);	
		//~ }	
	
	return 0;
}
