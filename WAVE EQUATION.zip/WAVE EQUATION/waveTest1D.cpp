// 1. Serial Code:
// 2. Parallel Codes:
//		--> OpenMP (CPU)
//		--> OpenACC (GPU)
//		--> MPI (CPU)
//		--> CUDA (GPU)
 			
#include <iostream>
#include <cstdlib>
#include <math.h>
#include <iomanip>
#include <cmath>
#include <limits>

#define N 5
#define m 10

double f(double x)
{
	const double pi = 3.14159265359;
	return sin(pi * x);
}

double g(double x)
{
	return 0;
}

int main()

{	
	//Step one 
	double l = 1.0, T = 1.0;
	const double alpha = 2.0;
	double h = l/m;
	double k = T/N;
	double lambda;
	lambda = k*alpha / h;
	
	//Step two
	//Creating dynamic array 	
	double *w0;
	w0 = (double*) malloc(m*sizeof(double));
	double *w1;
	w1 = (double*) malloc(m*sizeof(double));
	double *w;
	w = (double*) malloc(m*sizeof(double));

	w[0] = 0;
	w[m] = 0;
	//Step three
	
	w0[0] = 0; // boundary conditions f(0)
	w0[m] = 0; // boundary conditionsf(l)

	//Step four   : The approximation of the wave equation at the t=0, this is an initial conditions of the wave profile
	// and time t = k.
	for (int i = 1; i < m; i++)
	{
		w0[i] = f(i*h);
		w1[i] = (1 - pow(lambda,2))*f(i*h)+(pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h); 
	}
	
	//Step five : This is the approximation of the wave equation at (xi,tj) where i = 1,..,m-1 and j = 1,..,N-1
	for (int j = 1; j < N; j++)
	{
		for (int i = 1; i < m; i++)
		{
			w[i] = 2*(1-pow(lambda,2))*w1[i] + pow(lambda,2)*(w1[i+1] + w1[i-1])-w0[i];
			
		}	
		//Here we have to update the previous approximation of the wave profile to compute the next profile
		for(int i = 1; i < m; i++)
		{
			w0[i] = w1[i];
			w1[i] = w[i];
		}
	}
	//Step six : 
	double t,x;
	std::cout<<"x"<<"    \t  "<<"wij"<<std::endl;
	
	// Generating Mesh Points: Values of t and x; (xi,tj)
	for (int j = 0; j <= N; j++)
	{
		t = j*k;
		for (int i = 0; i <= m; i++)
		{
			x = i*h;	
		}
	}
	
	// OUTPUT when j = 20 (Use FSTREAM to write to a file)
	for (int i = 0; i <= m; i++)
	{
		x = i*h;
		std::cout.precision (10); // Setting the precision to be 10 digits
		std::cout <<x <<"\t  "<<w[i] <<std::endl;	
	}
	
	return 0;
}
