#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//#define N 20
//#define m 10
int m = 3;
int N = 3;
double f(double x)
{
	const double pi = 3.14159265359;
	return sin(pi * x);
}

double g(double x)
{
	return 0;
}
int main()
{
	//Step one 
	double l = 1.0, T = 1.0;
	const int alpha = 2.0;
	double h = l/m;
	double k = T/N;
	double lambda;
	lambda = k*alpha / h;
	int i,j;
	//Step two
	//double w[m+1][N+1];
	//N == Row == j
	//m == Col == i
	
	double *w = (double *)malloc((N) * (m) * sizeof(double)); 
	
	for (j = 1; j <= N; j++)
	{
		*(w + 0*m +j) = 0;
		*(w + m*m +j) = 0;
		printf(" first one %d\n", (0*m +j));
		//printf(" second one %d\n", (m*m +j));
		//w[0][j] = 0;
		//w[m][j] = 0;
	}
	
	//Step three
	//*(w + i*m + j)
	
	*(w + 0*m +0) = f(0);
	*(w + m*m +0) = f(l);
	
	//w[0][0] = f(0);
	//w[m][0] = f(l);
	
	//Step four
	for (i = 0; i < m; i++)
	{
		
		*(w + i*m +0) = f(i*h);
		*(w + i*m +1) = (1 - pow(lambda,2))*f(i*h)+
		 (pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h);
	}
	//~ for (int i = 1; i < m; i++)
	//~ {
		//~ w[i][0] = f(i*h);
		//~ w[i][1] = (1 - pow(lambda,2))*f(i*h)+
		//~ (pow(lambda,2)/2)*(f((i+1)*h)+f((i-1)*h)) + k*g(i*h); 
	//~ }
	
	
	//Step five
	
	for (i = 0; i < N; i++)
      for (j = 0; j < m; j++)
    
         *(w + i*m +(j+1)) = 2*(1-pow(lambda,2))* (*(w + i*m +j)) + 
         pow(lambda,2)*(*(w + (i+1)*m +j) + (*(w + (i-1)*m +j)))- (*(w + i*m +(j-1))); 
    
	
	//~ for (int j = 1; j < N; j++)
	//~ {
		//~ for (int i = 1; i < m; i++)
		//~ {
			//~ w[i][j+1] = 2*(1-pow(lambda,2))*w[i][j] + 
			//~ pow(lambda,2)*(w[i+1][j] + w[i-1][j])-w[i][j-1];
		//~ }
		
	//~ }
	
	//Step six
	//~ printf("x \t\t\t wij\n");
	//~ double t,x;
	//~ for (int j = 0; j < N; j++)
	//~ {
		//~ t = j*k;
		//~ for (int i = 0; i < m; i++)
		//~ {
			//~ x = i*h;		
		//~ }	
	//~ }
	
	//~ double t,x;
	//~ printf("x \t\t\t wij\n");
	//~ for ( i = 0; i <= m; i++)
		//~ {	
			//~ x = i*h;
			//~ printf("%f\t\t%f\n",x,*(w+i*m+20));	
		//~ }	
		
		
		printf("The matrix elements are:\n");
		for (i = 0; i < N; i++) {
		for (j = 0; j < m; j++) {
        printf("%f ", *(w + i*m + j)); 
      }
      printf("\n");
   }
	//~ free(w); 
	return 0;
}

