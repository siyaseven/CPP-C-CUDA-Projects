#include <iostream>
#include <vector>
#include <algorithm>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define MASTER 0
#define n 11

int main (int argc, char *argv[])

{

	int *a, *b;
	a = (int*) malloc(n*sizeof(int));
	b = (int*) malloc(n*sizeof(int));
	int nprocs, myrank,npp,i;
	MPI_Request req;
	MPI_Status status;
	//Activate MPI
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	
	// Creating and array b using the master core
	if (myrank == MASTER)
	{
		for (i = 1; i <= n; i++)
		{
			b[i] = i;
		}	
	}
	
	//Initializing subarrays for pa
	npp = n/nprocs; // number of jobs per processor
	npp+=1;
	int *ap, *bp;
	ap = (int*) malloc(npp*sizeof(int));
	bp = (int*) malloc(npp*sizeof(int));
	//std::cout<<" Number of nodes = "<<npp<<std::endl;
	
	//Distributing data of array b from MASTER node to other nodes
	MPI_Scatter(b, npp, MPI_INT, bp, npp,MPI_INT, MASTER, MPI_COMM_WORLD);
	
	//Calculating the algorthm in subsection using different nodes
	for (i = 1; i <= npp; i++)
	{
		ap[i] = bp[i-1] + bp[i+1];
	}
	
	//Gathering Data from other nodes
	MPI_Gather(ap,npp, MPI_INT, a,npp, MPI_INT, MASTER, MPI_COMM_WORLD);
	
	for (i = 0; i < n; i++)
	{
		std::cout<<a[i]<<std::endl;
	}
	//Free up the memory
	
	if (myrank == MASTER)
	{
		delete(b), delete(a);
	}
	delete(ap), delete(bp);
	//Deactivate MPI
	MPI_Finalize();
	
	return 0;
}
