#include <iostream>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

/* MIN: returns the minimum of two numbers */
int min(int num1, int num2)
{
	return (num1 > num2 ) ? num2 : num1;
}

/* dataRange: used to share data among the MPI processes */  
int n = 11; 
void dataRange(int n1,int n2, int nprocs, int myrank, int *ista, int *iend)
{
	// Calculates the range of iterations for a particular process
	int iwork1, iwork2;
	iwork1 = (n2-n1+1)/nprocs;
	iwork2 = (n2-n1+1) % nprocs;
	*ista= myrank*iwork1 + n1 + min(myrank, iwork2);
	*iend = *ista + iwork1 - 1;
	if(iwork2 > myrank)
	{
		*iend = *iend + 1;
	}
}

int main(int argc, char **argv)
{
	
	//~ int *a, *b;
	//~ a = (int*) malloc(n*sizeof(int));
	//~ b = (int*) malloc(n*sizeof(int));
	int a[n], b[n], c[n];
	int nprocs, myrank,ista,iend;
	int inext, iprev, iend1, ista2, MASTER=0;
	MPI_Request isend1, isend2, irecv1, irecv2, isend3, irecv3;
	MPI_Status status;
	//Activate MPI
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	dataRange(0,n-1,nprocs,myrank,&ista,&iend);
	
	ista2 = ista;
	iend1 = iend;
	
	
	if (myrank == 0)
	{
		ista2 = 1;
	}
	
	if (myrank == nprocs - 1)
	{
		iend1 = n - 2;
	}
	
	inext = myrank + 1;
	iprev = myrank - 1;
	
	if (myrank == nprocs - 1)
	{
		inext = MPI_PROC_NULL;
	}
	
	if (myrank == 0)
	{
		iprev = MPI_PROC_NULL;
	}
	
	for (int i = ista; i <= iend; i++)
	{
		b[i] = i+1;
	}	
	
	
	MPI_Isend(&b[iend], 1, MPI_INT, inext, 1, MPI_COMM_WORLD, &isend1);
	
	MPI_Isend(&b[ista], 1, MPI_INT, iprev,1, MPI_COMM_WORLD, &isend2);
	
	MPI_Irecv(&b[ista-1], 1, MPI_INT, iprev,1, MPI_COMM_WORLD,&irecv1);
	
	MPI_Irecv(&b[iend+1], 1, MPI_INT, inext,1, MPI_COMM_WORLD,&irecv2);
	
	MPI_Wait(&isend1, &status);
	MPI_Wait(&isend2, &status);
	MPI_Wait(&irecv1, &status);
	MPI_Wait(&irecv2, &status);

	//printf("myrank = %d ista2 =  %d iend =  %d\n",myrank, ista2, iend);

	for (int i = ista2; i <= iend1; i++)
	{
		a[i] = b[i-1] + b[i+1];
		
	}
	//a[1] = a[n];
	
	if(myrank == nprocs - 1)
	{
		for(int i = ista2; i <= iend1; i++)
		{
			MPI_Isend(&a[i], 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &isend3);
		}
		
	}
	if(myrank == 0)
	{
		for(int i = ista2; i <= iend1; i++)
		{
			MPI_Irecv(&a[i], 1, MPI_INT, nprocs-1,1, MPI_COMM_WORLD, &irecv3);
		}
	}
	
	
	
	//MPI_Allgather( a , 1, MPI_INT , c, 1, MPI_INT ,MPI_COMM_WORLD);
	//MPI_Gather(&a, iend, MPI_INT, c, iend, MPI_INT, MASTER, MPI_COMM_WORLD);
	
	
	//~ for (int i = ista2; i <=iend1; i++)
	//~ {
		//~ printf("myrank = %d  a[%d] =  %d\n",myrank, i, irecv3);
	//~ }	
	
	
	if(myrank == 0)
	{
		for(int i = ista2; i <= iend1; i++)
		{
			printf("myrank = %d  a[%d] =  %d\n",myrank, i, a[i]);
			
		}
	}

	//printf("%d %d\n",isend3, &irecv3);
	//free(b), free(a);
	
	//printf("I am rank %d working in the MPI parallel environment %d \n",myrank, nprocs);
	//std::cout<<"myRank is "<<myrank<<" starting at "<<ista<<" ending at "<< iend<<std::endl;
	
	//Deactivate MPI
	MPI_Finalize();
	
	return 0;
}
