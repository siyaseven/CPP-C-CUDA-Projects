#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <iterator>

using namespace std;


bool isValidArrayAndN(int N, vector<int> &A)
{
    //N and M are integers within the range [1..100,000];
    //each element of array A is an integer within the range [1..N + 1].


    /* ASSUMPTIONS */
    /* Exit program if the entered array is empty */
    if (A.empty())
    {
        return 0;
    }

    /* Range for the integer N */
    /* Check the length/size limits of the array */
    int M = A.size();
    if (M > 1000000)
    {
        return 0;
    }
    // N are counts (given by user)
    if (N < 1 || N > 1000000)
    {
        return 0;
    }

    /* Check the value limits for the array elements */
    // Declaration of an iterator to the vector-array for checking limits
    vector<int>::iterator minElement, maxElement;
    minElement = min_element(A.begin(), A.end());
    maxElement = max_element(A.begin(), A.end());
    if (*minElement < 1 || *maxElement > N+1) {
        return 0;
    }

    return 1;
}


vector<int> solution(int N, vector<int> &A)
{
    vector<int> valuesOfTheCounters = {};
    /* Check validity of the assumptions */
    if (!isValidArrayAndN(N, A)) return valuesOfTheCounters;

    // Initialize valuesOfTheCounters
    for (int i = 0; i < N ; ++i){
        valuesOfTheCounters.push_back(0);
    }

    int X;

    for( unsigned int K = 0; K < A.size(); ++K){
        X = A[K];
        if (X==N+1){
            vector<int>::iterator maxCounter;
            maxCounter = max_element(valuesOfTheCounters.begin(), valuesOfTheCounters.end());
            
            for (int i = 0; i < N ; ++i){
                valuesOfTheCounters[i] = *maxCounter;
            }
        }
        valuesOfTheCounters[X-1]++;
    }

    return valuesOfTheCounters;
}

int main()
{
    int N = 5;
    vector<int> A{3, 4, 4, 6,1, 4, 4};
    vector<int> valuesOfTheCounters;
    // Get the values of the counters
    valuesOfTheCounters = solution(N, A);

    for (auto v: valuesOfTheCounters){
        std::cout<< "value = " << v << std::endl;
    }
    
    return 0;
}

