#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;


bool isValidArray(vector<int> &A)
{
    /* Exit program if the entered array is empty */
    if (A.empty())
    {
        cout <<" Entered array is empty !" << endl;
        return false;
    }

    /* Check the length/size limits of the array */
    if (A.size() < 2 || A.size() > 100000)
    {
        cout <<" Size of the entered array is below or beyond limits !" << endl;
        return false;
    }

    /* Check the value limits for the array elements */
    // Declaration of an iterator to the vector-array
    //vector<int>::iterator elementPtr;
    // Loop over vector elements using begin() and end()
    /*for (elementPtr = A.begin(); elementPtr < A.end(); elementPtr++)
    {
        cout << *elementPtr << " ";
        if (*elementPtr < -1000 || *elementPtr > 1000)
        {
            return false;
        }

    }*/

    if ((*min_element(A.begin(), A.end()) < -1000) || (*max_element(A.begin(), A.end()) > 1000))
    {
        cout <<" Mininum and maximum values  of the required array is below or beyond limits !" << endl;
        return false;
    }
    cout << "\n ";
    return true;
}


int solution(vector<int> &A)
{
    /* Check assumptions/validity */
    isValidArray(A);
    /* Body/Engine*/
    int N = A.size();

    vector<int> leftPartOfArray;
    vector<int> rightPartOfArray;

    //int splitDifference = 0, minSplitDifference = 0;
    int minSplitDifference;
    vector<int> splitDifference;


    //int P = 1;
    // create left array

    for(int P = 1; P < N; P++)
    {
        int leftSum = 0;
        int rightSum = 0;
        for (int i = 0; i < N; i++) {
            if (i < P) {
                leftPartOfArray.push_back(A[i]);
                leftSum += A[i];

            }
            if (i >= P) {
                rightPartOfArray.push_back(A[i]);
                rightSum += A[i];

            }
        }

        //cout<< " Split Difference Element = " << abs(leftSum - rightSum) << endl;
        splitDifference.push_back(abs(leftSum - rightSum));
        minSplitDifference = *min_element(splitDifference.begin(),splitDifference.end());

        /*cout << " " << endl;
        cout << "When P = " << P << endl;
        cout << "Sum of the left part of array " << leftSum << endl;
        cout << "Sum of the right part of array " << rightSum << endl;
        cout << " " << endl;*/

        //cout<< " The minimum difference = " << minSplitDifference << endl;

    }

    return minSplitDifference;
}


int main()
{
    vector<int> A{3,1,2,4,3};
    //int something =
    int minSplitDifference = solution(A);
    cout<< " Mininum Split Difference = " << minSplitDifference <<endl;

}

	
	
	
