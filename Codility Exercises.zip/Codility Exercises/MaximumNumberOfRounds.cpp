#include <iostream>
#include <algorithm>
#include <cmath>
#include <string>

using namespace std;

int NumberOfFullRounds(string &A_HH, string &B_HH, string &A_MM, string &B_MM){
    int numberOfFullRounds;

    // start-time
    if (stoi(A_MM) == 0) {
        A_MM = "00";
    }
    else if (stoi(A_MM) > 0 && stoi(A_MM) <= 15) {
        //Int1_A_MINUTE = 15;
        A_MM = "15";
    }
    else if (stoi(A_MM) > 15 && stoi(A_MM) <= 30) {
        //Int1_A_MINUTE = 30;
        A_MM = "30";
    }
    else if (stoi(A_MM) > 30 && stoi(A_MM) <= 45) {
        //Int1_A_MINUTE = 45;
        A_MM = "45";
    }
    else if (stoi(A_MM) > 45 && stoi(A_MM) <= 59) {
        //Int1_A_MINUTE = 00;
        A_MM = "60";
    }

    // end time - Minute
    if (stoi(B_MM) == 0) {
        B_MM = "60";
    }
    else if (stoi(B_MM) > 0 && stoi(B_MM) <= 15) {
        B_MM = "00";
    }
    else if (stoi(B_MM) > 15 && stoi(B_MM) <= 30) {
        B_MM = "15";
    }
    else if (stoi(B_MM) > 30 && stoi(B_MM) <= 45) {
        B_MM = "30";
    }
    else if (stoi(B_MM) > 45 && stoi(B_MM) <= 59) {
        B_MM = "45";
    }

    A_HH += A_MM; // start-time HH:MM
    B_HH += B_MM;  // end time HH:MM
    cout << " A_HH = " << A_HH << endl;
    cout << " B_HH = " << B_HH << endl;

    numberOfFullRounds = 1; //(stoi(B_HH) - stoi(A_HH)) / 15;

    return numberOfFullRounds;
}

int solution(string &A, string &B) {
    int maximumNumberOfFullRounds;
    if (A.empty() && B.empty()) return false;
    if (A.size() > 5 && B.size() > 5) return false;

    string A_HH = A;
    string B_HH = B;

//    cout << " A_HH = " << A_HH << endl;
//    cout << " B_HH = " << B_HH << endl;


    string A_MM = A;
    string B_MM = B;

//    cout << " A_MM = " << A_MM << endl;
//    cout << " B_MM = " << B_MM << endl;


    for (int i = 0; i < A.size() - 2; i++) {
        A_HH.erase(A_HH.begin() + (A_HH.size() - 1));
        B_HH.erase(B_HH.begin() + (B_HH.size() - 1));
    }

//    cout << " A_HH = " << A_HH << endl;
//    cout << " B_HH = " << B_HH << endl;



    for (int i = 0; i < A.size() - 2; i++) {
        A_MM.erase(A_MM.begin());
        B_MM.erase(B_MM.begin());
    }

    //    cout << " A_MM = " << A_MM << endl;
    //    cout << " B_MM = " << B_MM << endl;

    // start time - Minute
    // in the same hour range



    if (stoi(A_HH)  == stoi(B_HH)) {
        maximumNumberOfFullRounds = NumberOfFullRounds(A_HH, B_HH, A_MM, B_MM);
    }

    /*else if (stoi(A_HH)  < stoi(B_HH)) {
        // between start-time and time after-to-start-time
        // start-time HH:MM
        int increment_A_HH;
        increment_A_HH += stoi(A_HH);

        string NextAfterToStartTime_HH = to_string(increment_A_HH);
        string NextAfterToStartTime_MINUTE = "00";
        maximumNumberOfFullRounds = NumberOfFullRounds(A_HH, NextAfterToStartTime_HH, A_MINUTE, NextAfterToStartTime_MINUTE);

        // between after-to-start-time and time before-to-end-time
        // between time before-to-end-time and end-time
    }*/
//    for (int i = stoi(A_HH); i < stoi(B_HH); i++){
//        //cout << " A_HH = " << A_HH << endl;
//        //cout << " B_HH = " << B_HH << endl;
//        string NextAfterToStartTime_HH = A_HH;
//        string NextAfterToStartTime_MM = "00";
//        maximumNumberOfFullRounds += NumberOfFullRounds(A_HH, NextAfterToStartTime_HH, A_MM, NextAfterToStartTime_MM);
//        int increment_A_HH;
//        increment_A_HH += stoi(A_HH);
//        NextAfterToStartTime_HH = to_string(increment_A_HH);
//        A_HH = NextAfterToStartTime_HH;
//        //string NextAfterToStartTime_MM = "00";
//    //    A_HH = to_string(increment_A_HH);
//    }

    return maximumNumberOfFullRounds;
}


int main()
{
    string A = "12:01";
    string B = "12:44";
//
//    string A = "20:00";
//    string B = "06:00";

//    string A = "00:00";
//    string B = "23:00";

//    03:12 - 16:36

    //string A = "";
    //string B = "";
    //vector<int> A{};

    int a = 04;

    std::cout << "a = " << a << std::endl;

    int maximumNumberOfFullRounds = solution(A, B);
    cout<< "maximumNumberOfFullRounds = " << maximumNumberOfFullRounds << endl;
//    cout<< " The value of the unpaired element is "<< maximumNumberOfFullRounds <<endl;
//    cout<<" " << endl;

    // Print vector
    /*for (auto v: valuesOfTheCounters){
        std::cout<< "value = " << v << std::endl;
    }*/

    return 0;
}
