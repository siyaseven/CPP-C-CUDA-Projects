#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool isValidArray()
{
	
}

int solution(vector<int>&A)
{
	
	return 0;
}


int main()
{
	return 0;
}
