/*
 * 
 * Author: Siyabonga Mthiyane
 * 
 * Date: 01 August 2021
 * 
 */ 

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "baccarat.h"

using namespace std;

int main() 
{
	DeckOfCards Deck;
	Shoe hand;
	
	// Generating two cards for a player and a banker.
	int p1 = hand.newCard();
	int p2 = hand.newCard();
	int b1 = hand.newCard();
	int b2 = hand.newCard();

	// Calculating the total points of both player and banker.
	int pTotal = (Deck.CardValue[p1]+Deck.CardValue[p2]) % 10;
	int bTotal = (Deck.CardValue[b1]+Deck.CardValue[b2]) % 10;

	// To check if we have "natural".
	bool endGame = false;
	endGame = natural(pTotal, bTotal);

	// Checking player or the banker if have a third card.
	bool pThirdCard = false;
	bool bThirdCard = false;

	// Declaring third card for both Player and Banker
	int p3;
	int b3;

	// Determining third conditions
	if (endGame == false) 
	{
		// Third Conditions for a player.
		if (pTotal < 6)
		{
			p3 = hand.newCard();
			pTotal = ((pTotal + Deck.CardValue[p3]) % 10);
			pThirdCard = true;
			
			// Third Conditions for a banker.
			if (thirdCardRule(Deck.CardValue[p3]) >= bTotal)
			{
				b3 = hand.newCard();
				bTotal = ((bTotal + Deck.CardValue[b3]) % 10);
				bThirdCard = true;
			}
		}
		 
		// Banker's third conditions given that the player total of 6 or 7.
		else if(bTotal < 6) 
		{
			b3 = hand.newCard();
			bTotal = ((bTotal + Deck.CardValue[b3]) % 10);
			bThirdCard = true;
		}
	}
	
	// Declaration of the outCome.
	string outCome;

	// Determining the outome of the game.
	if (pTotal > bTotal)
	{
		outCome = "PLAYER";
	} 
	else if (pTotal < bTotal)
	{
		outCome = "BANKER";
	} 
	else 
	{
		outCome = "TIE";
	} 
	
	// Displaying the outcome.
	cout << "PHand - BHand - Outcome" << endl;
	cout << Deck.CardCharacter[p1] << "," << Deck.CardCharacter[p2] << flush;
	if (pThirdCard) 
	{
		cout << ","  << Deck.CardCharacter[p3] << flush;
	}
	cout << " - " << flush;
	cout << Deck.CardCharacter[b1] << "," << Deck.CardCharacter[b2] << flush;
	if (bThirdCard) 
	{
		cout << ","  << Deck.CardCharacter[b3] << flush;
	}
	cout << " - " << flush;
	cout << outCome << endl;

	return 0;
}
