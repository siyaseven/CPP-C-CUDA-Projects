/*
 * 
 * Author: Siyabonga Mthiyane
 * 
 * Date: 01 August 2021
 * 
 * This file contains the declaration and the implementations.
 */ 

#ifndef RANDOMARRAYGENERATOR_H_INCLUDED
#define RANDOMARRAYGENERATOR_H_INCLUDED

#include <iostream>
#include <stdlib.h>
#include <time.h>

// Defining the three attributes of card as global variables.
const int rankCount = 13;
const int suitCount = 4;
const int numberOfDecks = 8;

struct DeckOfCards
{
	// Card values, 10 and face cards are worth zero.
	int CardValue[rankCount] = {1,2,3,4,5,6,7,8,9,0,0,0,0};
	
	// For printing the characters(A,J,Q,K and T (for 10)) ASCII is used.
	char CardCharacter[rankCount] = {65,50,51,52,53,54,55,56,57,84,74,81,75};
};

struct Shoe
{
	// Empty array to store drawn cards.
	int gameCards[rankCount][suitCount][numberOfDecks] = {{{0}}};
	
	// Getting a new card from the shoe and returning the value of the card.
	int newCard()
	{
		// Using srand() to generate random numbers.
		srand (time(0)); 

		// New card attributes defined.
		int rank;
		int suit;
		int deck;

		// Making sure we do not draw the same card again
		do
		{
			rank = rand() % rankCount;  
			suit = rand() % suitCount;  
			deck = rand() % numberOfDecks;  
		} 
		while(gameCards[rank][suit][deck] == 1);

		// Adding Card to the array. 
		gameCards[rank][suit][deck] = 1;

		return rank;
	}
};

// Checking if we have "natural" in the first two cards.
bool natural(int ptot, int btot)
{
	if(ptot > 7 || btot > 7)
	{
		return true;
	} 
	else 
	{
		return false;
	}
}

// Third card rules.
int thirdCardRule(int ptot)
{
	if(ptot == 8)
	{
		return 2;
	} 
	else if(ptot == 9)
	{
		return 3;
	} 
	else 
	{
		return static_cast<int>(ptot/2) + 3;
	}

	return 1;
}

#endif
